# A GPU-Accelerated Open-Source Python Package for Calculating Powder Difraction, Small-Angle-, and Total Scattering with the Debye Scattering Equation

Frederik L. Johansen <sup>1,2\*</sup>¶, Andy S. Anker <sup>3,4\*</sup>¶, Ulrik Friis-Jensen <sup>1,2</sup>, Erik B. Dam <sup>2</sup>, Kirsten M. Ø. Jensen <sup>1</sup>¶, and Raghavendra Selvan <sup>2</sup>¶

DOI: 10.21105/joss.06024

Software

• Review

• Repository

• Archive

Editor: Sophie Beck

## Reviewers:

• @marcocamma

• @elena-pascal

• @KedoKudo

Submitted: 05 October 2023 Published: 20 February 2024

## License

Authors of papers retain copyright and release the work under a Creative Commons Attribution 4.0 International License (CC BY 4.0).

1 Department of Chemistry & Nano-Science Center, University of Copenhagen, Denmark 2 Department of Computer Science, University of Copenhagen, Denmark 3 Department of Energy Conversation and Storage, Technical University of Denmark, Denmark 4 Department of Chemistry, University of Oxford, United Kingdom ¶ Corresponding author \* These authors contributed equally.

## Summary

The Debye scattering equation, derived in 1915 by Peter Debye, is used to calculate scattering intensities from atomic structures considering the position of each atom in the structure (Debye, 1915; Scardi et al., 2016):

$$
I (Q) = \sum_ {\nu = 1} ^ {N} \sum_ {\mu = 1} ^ {N} b _ {\nu} b _ {\mu} \frac {\sin (Q r _ {\nu \mu})}{Q r _ {\nu \mu}}\tag{1}
$$

In this equation $Q$ is the momentum transfer of the scattered radiation, � is the number of atoms in the structure, and $r _ { \nu \mu }$ is the distance between atoms � and $\mu .$ For X-ray radiation, the atomic form factor, $b ,$ depends strongly on $Q$ and is usually denoted as $f ( Q )$ , but for neutrons, � is independent of $Q$ and referred to as the scattering length. The Debye scattering equation can be used to compute the scattering pattern of any atomic structure and is commonly used to study both crystalline and non-crystalline materials with a range of scattering techniques like powder difraction (PD), total scattering (TS) with pair distribution function (PDF) analysis, and small-angle scattering (SAS) (Scardi et al., 2016). Although the Debye scattering equation is extremely versatile, the computation of the double sum, which scales $O ( N ^ { 2 } )$ , has limited the practical use of the equation.

With the advancement in computer hardware (Schaller, 1997), analysis of larger structures is now feasible using the Debye scattering equation. Modern central processing units $( \mathsf { C P U s } )$ ranging from tens to hundreds of cores ofer an opportunity to parallelise computations, significantly enhancing compute eficiency. The same goes for graphics processing units (GPUs), which are designed with multiple cores acting as individual accelerated processing units that can work on diferent tasks simultaneously. In contrast, CPUs usually have fewer cores optimised for more general-purpose computing. This means that a GPU can execute multiple simple instructions in parallel, while a CPU might handle fewer parallel tasks (Garland et al., 2008). Therefore, GPUs are better suited for calculations such as the Debye scattering equation, where many computations can be performed simultaneously. Taking advantage of such GPU acceleration could yield computational speeds that surpass those of even the most advanced multi-core CPUs; by orders of magnitude. We introduce a GPU-accelerated open-source Python package, named DebyeCalculator, for rapid calculation of the Debye scattering equation from chemical structures represented as .xyz or .cif files. The xyz-format is commonly used in materials chemistry for the description of discrete particles and simply consists of a list of atomic identities and their respective Cartesian coordinates (x, y, and z). DebyeCalculator can take a crystallographic information file (CIF) and a user-defined spherical radius as input to generate an .xyz file from which a scattering pattern is calculated. We further calculate the PDF as described by Egami and Billinge (Egami & Billinge, 2003). We show that our software can simulate PD, TS, SAS, and PDF data orders of magnitudes faster than DifPy-CMI (Juhás et al., 2015). DebyeCalculator is an open-source project that is readily available through GitHub and PyPI.

Here, we present a high-level overview of the DebyeCalculator class. The GitHub repository provides more details as well as annotated source code.

CLASS \`DebyeCalculator\`:

FUNCTION Initialise(parameters...):

\- Set class parameters based on given input or defaults

\- Setup scattering parameters (e.g., Q-values, r-values) and hardware parameters

\- Load atomic form factor coefficients

\- Setup form factor calculation based on radiation type

FUNCTION gr(structure\_path, keep\_on\_device=False):

\- Load atomic structure from given structure\_path

\- Calculate atomic form factors

\- Calculate scattering intensity I(Q) (Debye scattering equation)

\- Compute structure factor S(Q) based on I(Q)

\- Calculate F(Q) based on Q-values and S(Q)

\- Apply modifications if necessary (like dampening and Lorch)

\- Calculate pair distribution function G(r) based on F(Q)

\- Return G(r) either on GPU or CPU

In order to benchmark our implementation, we compare simulated scattering patterns from DebyeCalculator against DifPy-CMI (Juhás et al., 2015), which is a widely recognised software for scattering pattern computations. Here, our implementation obtains the same scattering patterns as DifPy-CMI (Figure 3), while being faster on CPU for structures up to \~20,000 atoms (Figure 1). Both calculations are run on a x86-64 CPU with 64GB of memory and a batch size of 10,000. Running the calculations on the GPU provides another notable boost in speed (Figure 1). This improvement primarily stems from the distribution of the double sum calculations across a more extensive set of cores than is feasible on the CPU. With smaller atomic structures, an overhead associated with initiating GPU calculations results in the NVIDIA RTX A3000 Laptop GPU computations being slower than DifPy-CMI and our CPU implementation. Once the atomic structure size exceeds \~14 Å in diameter (\~300 atoms), we observe a \~5 times speed-up using an NVIDIA RTX A3000 Laptop GPU with 6GB of memory and a batch size of 10,000. The choice of GPU hardware has a substantial influence on this speed advantage. As demonstrated in Figure 1, using an NVIDIA Titan RTX GPU, which ofers 24GB of memory, the speed benefits become even more evident. The NVIDIA Titan RTX GPU delivers a performance that is \~10 times faster, seemingly across all structure sizes, underlining the significant role of the hardware. With the advancements of GPUs like NVIDIA’s Grace Hopper Superchip (NVIDIA, 2024), which boasts 624GB of fast-access to memory, there is potential for DebyeCalculator to achieve even greater speeds in the future.

![](images/e8b817d22b4acfb6d8b318ae3a9f7b41aa2f887cce884c603e4bfc7bf56c9660.jpg)  
Figure 1: Computation-time comparison of the $G ( r )$ calculation using our CPU- and GPU-implementations against DifPy-CMI (Juhás et al., 2015). For the CPU-implementation, a batch size of 10,000 was chosen (x86-64 CPU with 6GB). Both the GPU implementations were run with a batch size of 10,000 (NVIDIA RTX A3000 Laptop GPU with 6GB of memory and NVIDIA Titan RTX GPU with 24GB of memory). The mean and standard deviation of the PDF simulation times are calculated from 10 runs. Note that, due to limited memory, the Laptop GPU was unable to handle structures larger than \~24,000 atoms. A CIF from an antifluorite structure was used to generate this data.

## Statement of need

Several software packages already exist for simulating the Debye scattering equation, including DifPy-CMI (Juhás et al., 2015), debyer (Wojdyr, 2023), Debussy (Cervellino et al., 2010, 2015), DISCUS (Th Profen & Neder, 1999; Thomas Profen & Neder, 1997), and BCL::SAXS (Putnam et al., 2015). DebyeCalculator stands out as it is open-source, Python-based, and GPU-compatible. Python’s status as an extremely popular and accessible language in scientific computing makes it straightforward for researchers to quickly perform Debye scattering calculations while ensuring easy integration with other data science tools. DebyeCalculator is open-source licensed under the Apache License 2.0. Moreover, it can be installed conveniently via pip install debyecalculator and has been integrated with Google Colab, allowing users to rapidly calculate PD, TS, SAS, and PDF data using the Debye scattering equation without the need of local software installations. DebyeCalculator can also be run through an interactive interface (see Figure 2), where users can calculate �(�), �(�), �(�), and �(�) from structural models on both CPU and GPU.

![](images/db9ed5df9e8167b48742e3f40d89fbe13531fdc7643d2bdfa090832d32e02f39.jpg)  
Figure 2: The interact mode of DebyeCalculator provides a one-click interface, where the user can update parameters and visualise �(�), �(�), �(�), and �(�). Additionally, the �(�), �(�), �(�), �(�), and .xyz file can be downloaded, including metadata.

## Acknowledgements

This work is part of a project that has received funding from the European Research Council (ERC) under the European Union’s Horizon 2020 Research and Innovation Programme (grant agreement No. 804066). We are grateful for funding from University of Copenhagen through the Data+ program.

## Supporting Information

![](images/ee3cee50e4c8f67f62c327bd37f1e1d36bdd3526660d2a9fc8be0635d514f805.jpg)

![](images/fc338a26fd8ee343a26cf83a1787661e3b08bf702933a6d3ba6888a928a4ed02.jpg)

![](images/d1b774fd69b46553ec459ec80c9495cd6f43bc1bfe968d054cb4d9917db268cc.jpg)

![](images/f6aae6ebac53f6ab69f1904b99f44fe7c723a069694d1168a66d3177de3fe101.jpg)  
Figure 3: Comparison of the calculated �(�), SAXS, �(�), and �(�) of DebyeCalculator and DifPy-CMI (Juhás et al., 2015) on a discrete, spherical cutout with 6 Å in radius from $\textsf { a V } _ { 0 . 9 8 5 } \mathsf { A l } _ { 0 . 0 1 5 } \mathsf { O } _ { 2 }$ crystal (Ghedira et al., 1977).

## References

Cervellino, A., Frison, R., Bertolotti, F., & Guagliardi, A. (2015). DEBUSSY 2.0: The new release of a Debye user system for nanocrystalline and/or disordered materials. J. Appl. Crystallogr., 48(6), 2026–2032. https://doi.org/10.1107/S1600576715020488

Cervellino, A., Giannini, C., & Guagliardi, A. (2010). DEBUSSY: A Debye user system for nanocrystalline materials. J. Appl. Crystallogr., 43(6), 1543–1547. https://doi.org/10. 1107/S0021889810041889

Debye, P. (1915). Zerstreuung von Röntgenstrahlen. Annalen der Physik, 351(6), 809–823. https://doi.org/10.1002/andp.19153510606

Egami, T., & Billinge, S. J. (2003). Underneath the Bragg peaks: Structural analysis of complex materials. Elsevier. https://doi.org/10.1016/c2010-0-66357-7

Garland, M., Le Grand, S., Nickolls, J., Anderson, J., Hardwick, J., Morton, S., Phillips, E., Zhang, Y., & Volkov, V. (2008). Parallel computing experiences with CUDA. IEEE Micro, 28(4), 13–27. https://doi.org/10.1109/MM.2008.57

Ghedira, M., Vincent, H., Marezio, M., & Launay, J. C. (1977). Structural aspects of the metal-insulator transitions in $V _ { 0 . 9 8 5 } A l _ { 0 . 0 1 5 } O _ { 2 } \dot { . }$ J. Solid State Chem., 22(4), 423–438. https://doi.org/10.1016/0022-4596(77)90020-2

Juhás, P., Farrow, C., Yang, X., Knox, K., & Billinge, S. (2015). Complex modeling: A strategy and software program for combining multiple information sources to solve ill

posed structure and nanostructure inverse problems. Acta Crystallogr. A, 71(6), 562–568. https://doi.org/10.1107/s2053273315014473

NVIDIA. (2024). NVIDIA grace hopper superchip data sheet - accessed: 2024-02-20. In NVIDIA. https://resources.nvidia.com/en-us-grace-cpu/grace-hopper-superchip

Profen, Th, & Neder, R. (1999). DISCUS, a program for difuse scattering and defect structure simulations–update. Journal of Applied Crystallography, 32(4), 838–839. https: //doi.org/10.1107/S0021889899004860

Profen, Thomas, & Neder, R. B. (1997). DISCUS: A program for difuse scattering and defect-structure simulation. Journal of Applied Crystallography, 30(2), 171–175. https: //doi.org/10.1107/S002188989600934X

Putnam, D. K., Weiner, B. E., Woetzel, N., Lowe Jr, E. W., & Meiler, J. (2015). BCL::SAXS: GPU accelerated Debye method for computation of small-angle X-ray scattering profiles. Proteins: Struct., Funct., Genet., 83(8), 1500–1512. https://doi.org/10.1002/prot.24838

Scardi, P., Billinge, S. J., Neder, R., & Cervellino, A. (2016). Celebrating 100 years of the Debye scattering equation. In Acta Crystallogr. A (No. 6; Vol. 72, pp. 589–590). International Union of Crystallography. https://doi.org/10.1107/S2053273316015680

Schaller, R. R. (1997). Moore’s law: Past, present and future. IEEE Spectrum, 34(6), 52–59. https://doi.org/10.1109/6.591665

Wojdyr. (2023). Wojdyr/debyer: Debye’s scattering equation and other analysis of atomistic models. In GitHub. https://github.com/wojdyr/debye